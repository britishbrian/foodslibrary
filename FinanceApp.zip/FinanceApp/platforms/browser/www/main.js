var budget = 0;
var expenses = 0;

var budgetEnter = prompt("Enter your budget.");

if (budgetEnter > 0) {
	
	budget = parseFloat(budgetEnter);
	
}


function menuOpen() {

	document.getElementById("menuSidebar").style.display = "block";

}

function menuClose() {
	
	document.getElementById("menuSidebar").style.display = "none";

}

  window.onload = function () {
    var chart = new CanvasJS.Chart("chartContainer",
    {
      title:{
        text: "Budget/Expenses"
      },
      data: [
      {
       type: "doughnut",
       dataPoints: [
       {  y: budget, indexLabel: "Budget" },
	   {  y: expenses, indexLabel: "Expenses" },
       ]
     }
     ]
   });

    chart.render();
  }
  
function addExpense () {
	
	
	document.getElementById("expensePage").style.display = "block";
	
	
}


function expenseSubmit () {

	var expensesDet = document.getElementById("exCost").value;
	
	expenses = expenses + parseFloat(expensesDet);
	budget = budget - expenses;
	
	barChange01();

}


function barChange01 () {
	
    var chart = new CanvasJS.Chart("chartContainer",
    {
      title:{
        text: "Budget/Expenses"
      },
      data: [
      {
       type: "doughnut",
       dataPoints: [
       {  y: budget, indexLabel: "Budget" },
	   {  y: expenses, indexLabel: "Expenses" },
       ]
     }
     ]
   });

    chart.render();
  }